let inp =  ["abc", "ded"]; 

function addBorder(a) {
    let top = '*'.repeat(a[0].length);
    a.unshift(top);

    for(let i = 0; i < a.length; i++){
        a[i] = a[i] + '*';
        a[i] = '*' + a[i];
    }

    let bottom = '*'.repeat(a[1].length);
    a.push(bottom);
 
    return a;
}

const pattern = addBorder(inp)
console.log(pattern)



